package com.cg.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;
import com.cg.entity.Account;
import com.cg.service.AccountService;

@RestController
public class Controller {
	
	
	@Autowired AccountService service;
	@GetMapping(value="/accounts",produces= {"application/json"})
	public List<Account> getall() {
	return service.getAllAccounts();
		
	}
	
	
	@PostMapping(value="/new",consumes={"application/json"})
	public String add(@RequestBody Account account) {
		 service.addAccount(account);
		 return"Account added";
	}
	
	 @GetMapping(value="/find/{mobileno}")	
	    public Optional <Account> findbyMobileno(@PathVariable Long mobileno) {
	        return service.findAccount(mobileno);
	 }

	 @GetMapping(value="/delete/{mobileno}")	
	    public String deletebyMobileno(@PathVariable Long mobileno) {
	       service.deleteAccount(mobileno);
	       return "Account deleted";
	 }
	 
	 @GetMapping(value="/deleteAll")	
	    public String deleteAll() {
	       service.deleteAll();
	       return "All Account deleted";
	 }
	 
	 @GetMapping(value="/withdraw/{mobileno}/{amount}")	
	    public String withdraw(@PathVariable Long mobileno,@PathVariable Double amount) {
		 service.withdraw(mobileno, amount);
	      
	       return "Amount has been withdrawn";
	 }
	 
	 @GetMapping(value="/deposit/{mobileno}/{amount}")	
	    public String deposit(@PathVariable Long mobileno,@PathVariable Double amount) {
		 service.Deposit(mobileno, amount);
	      
	       return "Amount has been Deposited";
	 }
	 
	 @GetMapping(value="/transfer/{from}/{to}/{amount}")	
	    public String transfer(@PathVariable Long from,@PathVariable Long to,@PathVariable Double amount) {
		service.TransferMoney(from, to, amount);
	      
	       return "Amount has been transferred";
	 }
}
